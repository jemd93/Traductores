
# -------------------------------------------------
#  Universidad Simón Bolívar
#  Traductores e interpretadores - CI3725
#  Prof. Ricardo Monascal
#
#  Autores: Jorge Marcano   # Carnet 11-10566
#           Meggie Sánchez  # Carnet 11-10939
#
# Proyecto BOT - Etapa 1 - Análisis Lexicográfico
# -------------------------------------------------

Este archivo contiene algunos detalles extras respecto al proyecto.

El Script LexBot es un bash script que se encarga de correr el programa principal del proyecto con
un archivo de texto como parámetro. De manera que, ./LexBot <Archivo> corre el programa principal
del proyecto con <Archivo> como entrada.

Dicho script correrá el programa LexBot.py que es donde se encuentra todo el código de ésta
etapa del proyecto.

Notese que el Script LexBot utiliza el comando python3 debido a que la versión de python utilizada
para la ejecución del proyecto es python 3.4. En el supuesto de que se utilizara una versión anterior (2.x) 
de python para correr el programa, este devolverá la salida correcta, pero en formato incorrecto. 

Por último, el informe junto con la resolución de las preguntas teórico-prácticas se encuentra
en el archivo InformeEtapa1.pdf.