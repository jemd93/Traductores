
# -------------------------------------------------
#  Universidad Simón Bolívar
#  Traductores e interpretadores - CI3725
#  Prof. Ricardo Monascal
#
#  Autores: Jorge Marcano   # Carnet 11-10566
#           Meggie Sánchez  # Carnet 11-10939
#
# Proyecto BOT - Etapa 1 - Análisis Lexicográfico
# -------------------------------------------------

Este archivo contiene algunos detalles extras respecto al proyecto.

El Script LexBot es un bash script que se encarga de correr el programa principal del proyecto con
un archivo de texto como parametro. De manera que, ./LexBot <Archivo> corre el programa principal
del proyecto con <Archivo> como entrada.

Dicho script correra el programa LexBot.py que es donde se encuentra todo el codigo de esta
etapa del proyecto.

Notese que el Script LexBot utiliza el comando python3 debido a que la version de python utilizada
para la ejecucion del proyecto es python 3.4. En el supuesto de que se utilizara una version anterior (2.x) 
the python para correr el programa,este devolvera la salida correcta,pero en formato incorrecto. 

Por ultimo, el informe junto con la resolucion de las preguntas teorico-practicas se encuentra
en el archivo InformeEtapa1.pdf.